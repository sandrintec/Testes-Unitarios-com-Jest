export class Account {
    constructor(id, balance) {
        this.id = id;
        this.balance = balance;
    }
}